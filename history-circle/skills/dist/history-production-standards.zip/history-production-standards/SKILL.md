---
name: "history-production-standards"
description: "역사서클 롱폼·숏폼 제작의 자원 운용 기준 — 화면 색 규칙(청록산수 + 나라별 포인트색), 컷 생성 배분, 생성 전 최종 확인, 지도 프리셋, BGM 4무드, 제작 키트 백업·복구. 롱폼·숏폼 제작을 시작하거나 sandbox가 초기화됐을 때 다른 history-* 스킬과 함께 읽는다."
---

> **history-core를 먼저 읽는다.** 현행 값은 원장(decisions.yaml) 하나뿐 — 이 본문과 다르면 원장 우선. 폐기·보류·편별 이력·변경 이력 원문은 같은 폴더 `archive.md`(규칙으로 따르지 않음).

# 역사서클 제작 자원 운용 기준 (v1.2 · 2026-10-25 · 색 규칙·최종 확인 규칙 추가)

채널 정체성·편 구성은 history-channel-concept, 실제 제작 절차는 history-shorts / history-longform / history-architecture-shorts가 기준이다. 이 스킬은 그 위에서 '무엇을 새로 만들고 무엇을 재사용하나', '화면 색을 어떻게 고정하나', '도구를 잃지 않는 법'을 정한다.

> **충돌 규칙(11/04 개편 — history-core)**: 현행 값은 원장(decisions.yaml) 하나뿐이다. 이 스킬 본문과 원장이 다르면 원장을 따른다. 원장에 없는 항목끼리 부딪히면 기존 '날짜가 붙은 최신 사용자 결정' 원칙을 따른다(원문은 archive.md '교체 원문').

배경(10/23): 제미나이의 효율화 조언(키 비주얼+켄번스, 지도 템플릿, BGM 프리셋)을 검토해 사용자가 아래 수정안을 채택했다. 이번 대화에서 시간을 가장 많이 잃은 원인은 이미지 생성이 아니라 sandbox 초기화 뒤 렌더러·도구를 다시 세운 일이었다.

## 0. 화면 색 규칙 (10/25 사용자 확정 — 모든 편 공통, 가장 먼저 지킨다)

- **바탕은 언제나 정통 청록산수**: 석청(아주라이트)·석록(말라카이트)이 주색인 차갑고 맑은 채색 산수. 먹선 윤곽 + 채색, 흰 띠구름, 산 아래·땅에만 옅은 대자(붉은 갈색 흙빛), 집·다리·소품에 작은 주사(朱砂) 점. 빛은 맑고 고른 낮빛(이상향) — 특정 시간대 노을빛이 아니다.
- **나라 색은 '그 나라의 왕·군사'에만 포인트로**: 옷·망토·띠·깃발 등 인물에 붙은 면적만 칠한다. 화면 전체·하늘·땅·빛을 그 색으로 물들이지 않는다.

| 나라 | 포인트 색 | 적용 대상 | 확정일 |
|---|---|---|---|
| 백제 | 황금색 | 백제 왕(온조 등)·백제 군사의 옷·망토·띠·깃발 | 10/21~22(청색에서 변경), 적용 범위 10/25 |
| 신라 | 주홍(주사색, 저채도 madder-red 허용) | 신라 왕·주인공(탈해 등)·신라 군사 | 10/25 |
| 고구려 | 적갈 (96,34,29) 계열 — 지도 면색 기준 | [미확정 — 인물 포인트색은 사용자 확인 필요] | — |

- **프롬프트 금지어**: `golden hour`, `golden light`, `warm golden glow`, `sunset light`(노을 장면이 서사상 꼭 필요할 때만 예외), `warm ochre` 전체 톤. 이 말이 들어가면 화면 전체가 황색으로 덮여 백제 포인트와 구분이 사라진다(10/25 탈해 편에서 실제 발생 — 사용자 지적 "미감이 없다, 백제 황색과 너무 겹친다").
- **프롬프트 기본 문구(바탕)**: `authentic Korean blue-green landscape painting (cheongnok sansu): mineral azurite blue and malachite green dominant on peaks and rocks, crisp ink outlines filled with flat color, layered white ribbon clouds, pale ochre only on the ground, tiny cinnabar accents, clear even daylight, cool and luminous palette, on hanji paper`
- **밤 장면 예외**: 짙은 남색 + 횃불·불빛(대장간·밤 잠입 등)은 허용. 그래도 포인트 색 규칙은 같다.
- **10/23의 '금빛 빛'은 폐기**: 1절 표의 옛 문구('금빛 빛')는 이 규칙으로 대체된다. '밝은 첫 장면'은 유지(밝은 낮빛 청록으로).

## 0-1. 생성 전 최종 확인 (10/25 사용자 지적 — 반드시)

- **크레딧이 드는 생성(그림·움직이는 컷·음성 일괄)은 사용자의 최종 확인 뒤에만 낸다.** 검수(외부 검수자 포함)가 끝나면 바뀐 대본·장면 설계·예상 크레딧을 먼저 보여 주고 "진행" 답을 받은 다음 생성한다. "검수 후 진행"이라는 말은 확인 생략 허락이 아니다.
- **사용자와 대화로 정한 내용 > 검수 의견**: 검수 의견이 사용자와 이미 합의한 구성(예: 탈해 편 '마지막 10초 철기 이주 집단 해석 반전')을 빼거나 흐리게 만들면, 그대로 반영하지 말고 충돌을 사용자에게 보여 주고 고르게 한다(10/25 탈해 편: 각본가 의견대로 해석을 설명란으로 빼서 사용자 지적).
- 새 인물은 시안 1~2장(장당 1크레딧)으로 얼굴·표정을 먼저 확인받고 나머지 장면을 만든다(10/25 탈해 1차가 "너무 느끼하다"로 재작업).

## 1. 컷 자원 배분

| 구분 | 방식 |
|---|---|
| 숏폼 신작 | 키 비주얼 그림 8~10장 + 움직이는 컷 1~2개 + 줌·효과음. **색은 0절 규칙**(정통 청록산수 + 나라별 포인트색, 밝은 첫 장면, 광물 안료 색) |
| 롱폼 설명·판단 분석·지도 구간 | 키 비주얼 + 줌 + 먹 글씨(longform E-7). **한 장면 6초 이하, 같은 그림 재사용 금지, 지도↔실사 교차. 편당 총량 상한은 두지 않는다**(10/23, longform E-6) |
| 롱폼 전투·탈출 구간 | 움직이는 컷을 짧게 끊어 잇는 전투 문법(longform E-5·E-6) — 켄번스 정지 화면으로 대체하지 않는다(1부 '정지 화면이 루즈하다', 3부 '반복 컷·반복 클로즈업이 싫다', 칭기즈칸 영상 수준의 박진감 기준) |

- **크레딧 상한(10/24 확정)**: 롱폼 편당 **800**, 사용이 **560(70%)**에 닿으면 사용자에게 알리고 남은 컷 계획을 다시 짠다. 쇼츠 신작은 편당 30 안팎(기록 15~26). 생성 배치를 낼 때마다 누적 사용량을 기획안 문서 '제작 기록'에 적는다
- 단가(10/23 실측): GPT Image 2.5 그림 1장 = 1크레딧, Kling 3.0 5초 = 10크레딧, TTS 한 줄 ≈ 0.02크레딧. 움직이는 컷은 효과 대비 비싸므로 쇼츠에서는 첫 장면 1개 이하로 둔다
- **재사용 우선**: 새로 만들기 전에 인물 시트와 지난 편 컷을 먼저 찾는다(longform E-1 인물 시트, history-shorts L-5 재사용 목록, 아래 6절).
- 롱폼에서 만든 컷은 쇼츠 재편집(history-shorts M)으로 다시 쓴다(크레딧 0).

## 2. 지도
- 새 지도는 지도 키트(history-map-v4 v4-S — 원장 C1 11/04. 이전 표기 'longform E-3 mapkit, shorts L-0 지도 v3'는 archive.md)로만 만든다. 편마다 즉석에서 따로 그리지 않는다. 예외: 건축·도시 시리즈의 한지 먹선 도해 지도(history-architecture-shorts 7번).
- **시대별 세력 기본 지도 프리셋 [미제작]** — 한 번 구워 두고 편마다 표지·화살표만 얹는다:

| 프리셋 | 범위 | 상태 |
|---|---|---|
| BC 1세기 | 고구려·부여·낙랑·옥저·삼한(마한) | 백제 온조 롱폼 착수 때 가장 먼저 만든다 |
| 1~3세기 | 고구려·부여·한군현·백제·마한·진변한 | 미제작 |
| 4세기 | 고구려·백제·신라·가야·낙랑 축출 후 | 미제작 |
| 5~6세기 | 삼국 + 가야 | 미제작 |

- 백제 색 = **황금색 계열**(10/21~22, 청색에서 변경 — 옛 기록의 금칠 근거). 지도 면색은 진한 저채도 금갈색으로, 고구려 적갈 (96,34,29)·쇼츠 금색 강조 글자와 구분되게 BC 1세기 프리셋 제작 때 정한다. 신라 지도 면색은 주홍 계열 저채도로 같은 때 정한다
- 제미나이의 '제작 시간 40% 절감' 수치는 근거 미확인이라 판단 근거로 쓰지 않는다.

## 3. BGM 4무드 프리셋
사용자가 Suno 유료 플랜으로 만든 곡(상업 이용 가능). 드라이브 공유 폴더 `1sfx-ttR2vpY2DOcqKI_vPtqHi3qQm8ag`(링크가 있는 모든 사용자). 무드 배정은 [제안 — 사용자 확인 필요].

| 무드 | 곡(드라이브 id) | 쓰는 곳 |
|---|---|---|
| 긴장 | 北军将至 `1RXEDYRiN8XqHVdBTu8NVamnhQqyeya_E` · The Closing Trap `1Aoit34TGLpzqzwDrkhR_H2DyQn93Rmq8` | 포위·작전 회의·대치 |
| 전투 | Thunder of the Red Army `1a8isuMqMGuGS0sfZHR8JrooRJkfqReJW` · Snow Ambush `1DxTTJLT8XJtHG7Tzc6mYAaTe_DOOP9JI` | 전투·탈출·돌격 |
| 비극·여운 | 战后清晨 `1oXiS0tkN4ah1l6oW827UranZwjRtK34K` | 패배·자책·엔딩 |
| 비트 훅 | War Drum Silence `1as37pD90ip1a2obiy9Ws1pUWW0TQAJQF`(189.6초, 161 BPM, 앞 20초에 드럼 멈춤 3번: 3.5–6.5 / 10.0–12.7 / 15.4–16.6초) | 숏폼 예고편·롱폼 첫 10초 전투 플래시 |

- 그 밖의 곡: 雪地潜伏 `1IkHbRwob8UAZkvR5f3fLzmLLsgouphl7` · The Red Crow's Omen `1HBYI0EPhU2WcqNMLCCqYtd88dBiDYOjN` · Ink-Wash War `1SPHBC8f-w2rzbQDiUEEpw_Wjq6Oe41LQ` · The King's Departure `1c5OHM5d5lD2fguRnOKBINYX6NNzCu9zP` · Army on the Thawing Plain `1Q4e_1YG53XG8SinX_JOiyecWP81C_zVh`
- sandbox에서 받기: `curl -sSL -o x.wav "https://drive.usercontent.google.com/download?id=<id>&export=download&confirm=t"` (10/23 확인)
- 음량 기준은 기존 값 그대로(내레이션 > 음악 > 효과음, longform K·shorts F-6). 같은 곡 반복은 채널 소리 표식으로 본다.
- Suno 프롬프트(비트 훅, 10/21): 드럼을 맨 앞에, `stop-and-go groove with dramatic breaks`, `sudden full stops … then the drums slam back in hard`, `no plucked strings, no bells, no bright melody`, Lyrics 칸에 [Break]·[Stop] 구조 태그. 가수 이름은 넣지 않는다(Suno가 막음).

## 4. 제작 키트 백업·복구 (가장 중요)
- **원칙**: 작업 세션이 끝날 때마다, 새로 만들거나 고친 스크립트를 백업한다. sandbox는 언제든 초기화될 수 있고(10/23·10/25 실제로 초기화), 작업공간은 Higgsfield 업로드·CDN에 접근하지 못한다.
- **텍스트 스크립트(.py·.json)**: 작업공간에서 Google Drive `create_file`(`textContent`, `disableConversionToGoogleType: true`, `parentId` = 위 공유 폴더)로 올린다 → 폴더가 링크 공유라 sandbox에서 drive.usercontent 주소로 바로 받는다(10/23 검증).
- **바이너리·묶음(zip·폰트·이미지)**: sandbox에서 zip으로 묶어 `media_upload`(general file) + curl PUT + `media_confirm` → 받은 URL을 이 표에 적는다.
- **숏폼 신작 복구 순서(10/25 검증, 1분 이내)**: ① 폰트 5종을 history-shorts G-1의 GitHub 주소로 받는다(B·X·SM·NSK·SEAL) ② render.py를 드라이브 `kit_shorts_render_v7.6.py`에서 받고 md5 확인 ③ 내레이션 압축 comp.py는 드라이브 `kit_shorts_talhae_build.py` 안의 COMP 문자열을 꺼내 쓴다.

| 자산 | 위치 | 상태 |
|---|---|---|
| 숏폼 렌더러 render.py v7.6 | 드라이브 `kit_shorts_render_v7.6.py` id `1YYNzLR6RmFhGwLnQLVAoWwMwNYGVNYIo` + history-shorts G-4 본문(md5 197958161508814c8e813be3cb66864c) | 안전(10/25 복구 검증) |
| 숏폼 신작 빌드·내레이션 압축 | 드라이브 `kit_shorts_biryu_build.py` `13XeJNNwSfjwHECrpf8LVYnkVhODA8LpL` · `kit_shorts_wiryeseong_build.py` `1LmNnvmHKZldFNAYIWhEzkDgUl2PyVg3k` · `kit_shorts_talhae_build.py` `17obD5uOSmXIfmhB8gIzZQmlkCIeRP8Pp`(comp.py 포함) | 백업 완료 10/23~25 |
| 재편집 빌더 build_short.py **v8.1** | 드라이브 `kit_build_short_v81.py` id `1IZveJgYtsIoi9jn4kIGearse5LypZnNA`(11,713바이트, md5 1362e95870c47298b02436fd37ab0ba3) — 표준 화면(제목 92→80%·史 배지·워터마크) + wrap 패치 포함 | 백업 완료 10/23. M-7 본문은 v8.0(구판) |
| 3부 재편집 설정 | 드라이브 `kit_shorts_p3_cfgs.py` id `18P1ybBICaXzF-dPGxCn0w2QvBK7-wHVw` | 백업 완료 10/23 |
| 자막 OCR | 드라이브 `kit_shorts_ocr_subs.py` id `16zS7ZqX7dvYyYSrIt6NYvfwYb_UiRVYc` | 백업 완료 10/23 |
| 롱폼 키트 v1.2 | B + `bdedbf88-07ac-4224-9bd1-0ce6cec64236.zip` | 안전(CDN) |
| 롱폼 렌더러 v1.3·p3lib·p3build·도트 코드(sneak·rider) | sandbox `~/r`·`~/spr` | **유실(10/23 확인)** — 다음 롱폼 착수 때 longform G-1의 v1.3 변경 사항을 v1.2에 다시 적용하고 즉시 zip 백업 |
| 온조 비트 예고편 합성기 mont.py | sandbox `~/hs/onjo` | **유실** — 5절 방법으로 다시 짠다 |

- build_short.py **wrap 패치(10/22)**: 자막 줄바꿈이 `{금색 단어}` 안의 띄어쓰기를 고르면 ASS 태그가 깨져 단어가 사라졌다 → 중괄호 밖의 띄어쓰기만 고른다:
```python
    dep=0; sp=[]
    for i,c in enumerate(t):
        if c=='{': dep+=1
        elif c=='}': dep-=1
        elif c==' ' and dep==0: sp.append(i)
```
  (M-7의 `sp=[i for i,c in enumerate(t) if c==' ']` 한 줄을 이것으로 바꾼다.) 금색 단어 목록은 긴 단어부터 맞춘다(`sorted(words,key=len,reverse=True)` — '셋'이 '셋째'를 먼저 잡던 문제).
- 재편집 쇼츠 원본 준비 순서(10/22 3부): 그림 영역 PY 139 · PH 802(1·3부 동일) → 자막 띠 y 976~1040을 5fps로 잘라 OCR → 같은 자막끼리 묶고 FIX 표로 교정(화면 띠를 잘라 눈으로 확인) → 1초 접촉 시트로 컷별 모드(F·B)와 cx를 고른다. 접촉 시트 썸네일이 화면에 줄어 보이면 표시 좌표 × (원본 1920 / 표시 폭)으로 환산한다.
- sandbox에서 렌더를 끌 때 `pkill -f`는 자기 셸까지 죽인다(exit 143/144) → `ps -eo pid,args | awk`로 pid를 골라 kill.

## 5. 숏폼 비트 예고편(음악만, 내레이션 없음) — 10/20 온조 예고편
- 구성: 무음 → 붓글씨 지명 카드(박자마다 한 글자) → 실사·그림 컷 → 드럼 멈춤 구간에 카드 → 연타 구간에 0.35~0.7초 컷 5~6개 → 큰 타격에 먹 번짐 → 검은 먹 위 흰 붓글씨 제목 + 금색 부제 → 페이드
- 박자 분석: librosa `beat_track`·`onset_strength` + 타악 분리(`effects.percussive`) RMS로 멈춤 구간을 찾는다
- 붓글씨 카드: gpt_image_2_5로 흰 바탕 세로 붓글씨를 만들고 글자 정확도를 눈으로 확인 → 밝기로 알파를 뽑아 글자별 띠로 나눠 위→아래 와이프. 10/20 사용분: 卒本 `9e2794c1-50ba-42e9-a379-9663960e324f` · 負兒嶽 `d38b616e-e37b-402b-9c4a-7ce79599756a` · 慰禮城 `ca60d60e-1ab7-46a7-a82f-30823926d05f` · 百濟 `63b2c260-d872-4612-8035-5221d995ff1b`
- 화면 포맷은 표준(史 배지·워터마크·출처 줄)을 지키고, 제목은 마지막에 한 번
- 결과: v2(음악 포함) `1ed13617-3d4d-4695-9f2e-61990f7a134d.mp4`

## 6. 인물 시트 목록(재사용)
| 인물 | 시트 | 얼굴 | 비고 |
|---|---|---|---|
| 온조(중년 1인, 백제 황금색 포인트 — 10/21~22, 콧수염 + 짧은 턱수염 — 10/23) | `ff6019d1-ff06-4c1b-a539-b9aae31dddcf`(10/23 4면, 턱수염판) | `61df4347-c10f-48a9-bb36-0d56fd216617`(10/23 턱수염판 — **얼굴 기준은 이 컷**) | 실사. 턱수염 = 고구려 고분벽화 귀족 인물에서 착안한 짧고 단정한 수염([연출]). 4면 시트는 축소판에서 수염이 옅게 보이므로 얼굴 컷과 함께 참조. 이전판(금색·콧수염만 66aab96f·03247edf, 청색 7fdd1142·97004930)은 쓰지 않는다. 뒷모습 컷은 겉옷 전체가 금색으로 나왔다 — 앞모습(베이지 저고리 + 금색 망토·띠)이 기준. 숏폼 신작에 쓸 때는 청록산수로 다시 그린 시트를 하나 더 만든다 |
| 탈해(신라, 10대 후반 소년, 주홍 포인트 — 10/25) | — | 1차 `aa0531d5-25ef-4d20-add0-b0b6be4e6ef9`는 **쓰지 않는다**(사용자: "너무 느끼하다") | 재작업 방향: 능청스러운 미소 없이 담담·경계하는 표정, 미화하지 않은 평범한 얼굴, 그을린 마른 체형. 복식은 원삼국 기준(상투, 삼베 교임 포·띠, 주홍은 깃·띠에 저채도). 시안 확정 후 이 칸에 기록 |
| 무휼·노장·대소·청년 대무신왕·괴유·마로 | longform E-1 | — | 실사 |

## 8. 성과 장부 (10/23 신설 — 측정 루프)
- 업로드 **7일 뒤 1회**, 숫자 5개만 적는다: 노출수 · 노출 클릭률(CTR) · 0:30 유지율(롱폼 '인트로') / 계속 시청 비율(쇼츠) · 평균 시청 지속률 · 구독 전환. 사용자는 Studio 캡처만 주고 Claude가 적는다. 매주 월요일 저녁 예약 작업이 캡처를 요청한다
- 판정에 쓰는 실험: E2 첫 30초(0:30 유지율 ≥ 60%), 패키징 3안 테스트 결과, 쇼츠 관련 링크 효과(롱폼 트래픽 소스 중 '쇼츠' 비율, 4주)
- 기준선(10/23 캡처, 최근 28일): 채널 조회 2.6만(거의 쇼츠) · 쇼츠 계속 시청 40.3% · 쇼츠 유입 피드 95.5% · 시청자 신규 99.2% · 45세 이상 84.4%, 남성 89.4% · 롱폼 유입 탐색 65.3% / 추천 24.9% / 검색 4.6%

| 편 | 형식 | 업로드 | 7일 뒤 노출수 | CTR | 0:30 유지 / 계속 시청 | 평균 지속률 | 구독 | 메모 |
|---|---|---|---|---|---|---|---|---|
| 1부 〈열 살의 장수〉 | 롱폼 | 10/6 무렵 | — | — | 57%(365일) | — | — | 28일 조회 276 · 시그니처 없음 |
| 2부 〈진창의 벌판〉 | 롱폼 | 10/14 무렵 | — | — | 52%(365일) | — | — | 28일 조회 892 · 콜드 오픈 + 시그니처 10초 |
| 3부 〈칠 일의 안개〉 | 롱폼 | 10/17 이후 | — | — | — | — | — | 28일 조회 94 · 썸네일 A·B·C 테스트 대상 |

> 〔archive.md로 이동: '7. 결정 기록' — 변경 이력 표 — 현행 값은 원장〕
