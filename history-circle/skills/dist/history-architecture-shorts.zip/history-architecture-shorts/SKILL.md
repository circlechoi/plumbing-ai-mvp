---
name: "history-architecture-shorts"
description: "역사서클 건축·도시 시리즈 세로 쇼츠(45~60초) — 기본 형식 '그 시절 ○○'(그 시대 사람들은 왜 그렇게 짓고 살았나: 온돌 등)와 보류 중인 '도시의 일생'(블록 성장 지도)을 기획·고증·생성·렌더할 때 사용. '그 시절 고구려', '건축 쇼츠', '도시 쇼츠', '도시의 일생', '왜 이렇게 지었을까'."
---

> **history-core를 먼저 읽는다.** 현행 값은 원장(decisions.yaml) 하나뿐 — 이 본문과 다르면 원장 우선. 폐기·보류·편별 이력·변경 이력 원문은 같은 폴더 `archive.md`(규칙으로 따르지 않음).

# 역사서클 건축·도시 시리즈 쇼츠 (v0.4 · 2026-10-23 · 스킬 정비 — 두 형식, 설명란 원본은 history-shorts J, 마스터 태그)

이 스킬은 건축·도시 시리즈 전용 규칙만 담는다. 나머지는 기존 스킬을 그대로 쓴다.
- 정체성·두 형식·편 공식·주제 후보: **history-channel-concept 12번**(먼저 읽는다). 역할: '그 시절' = 기획자·디자이너(concept 0) + 1번 체크포인트 / '도시의 일생' = 세 역할(concept 12-1)

> **충돌 규칙(11/04 개편 — history-core)**: 현행 값은 원장(decisions.yaml) 하나뿐이다. 이 스킬 본문과 원장이 다르면 원장을 따른다. 원장에 없는 항목끼리 부딪히면 기존 '날짜가 붙은 최신 사용자 결정' 원칙을 따른다(원문은 archive.md '교체 원문').

- 생성 도구 사용법·내레이션(TTS)·움직이는 컷(Kling)·렌더러(render.py v7.6)·받아쓰기·QA·업로드 절차: **history-shorts** B·F·G·H·I·J
- 지도 v4-S(지역 위치가 필요할 때만): history-map-v4(원장 C1 11/04 — 이전 표기 'history-shorts L-0 지도 v3'는 archive.md)
- [확정 10/13] 사용자 결정: 역사서클 안 새 시리즈 / 실사 복원 + 코드 도해 / 양식 반·개발 논리 반
- [미검증] 표시는 첫 편에서 시안으로 확인한 뒤 지우고 결과를 결정 기록에 남긴다
- 도해 그림체 = 한지 먹선(10/13 사용자 결정), 단 그림이 주인공인 장면은 AI 그림 + 코드 표지(10/14). 도트 = 깨알 등장만

## ★ 화면 포맷은 반드시 history-shorts 표준 (10/19 사용자 지시)
- 렌더는 **history-shorts G-4의 render.py v7.6을 그대로** 쓴다(md5 197958161508814c8e813be3cb66864c 확인). sandbox가 초기화돼도 렌더러를 새로 짜지 않는다 — 스킬 파일에서 파트 A·B를 그대로 옮겨 쓰고 md5로 확인한다
- 표준 화면 요소(빠지면 안 됨): 상단 제목(본고딕 Black, 흰색+{금색} 핵심어, 첫 장면 크게 → 작게 고정) · 좌상단 史 낙관 + 금색 연도 배지(장면마다 `year`) · 우상단 `역사서클` 워터마크 · 송명 2줄 자막(1줄 ≤13자 / 2줄 ≤10자, 장면 요약형) · 출처 줄 · 지도 note
- 코드로 만든 특수 장면(먹 번짐 시그니처, 불길이 흐르는 단면, 확산 지도 등)은 **제목·자막 없이 mp4로 미리 렌더**해 scenes.json의 `video`로 넣는다(HUD는 render.py가 얹는다)
- 지도 위 표지는 render.py anim.json `markers`(붉은 원 + 이름. `[통설]` 등 화면 태그 부제는 빼고 설명란으로 — 원장 C5 11/04)로. × 표시 대신 이 표지를 쓴다(10/19 사용자 지정)
- 도트는 sprite.py 방식(장면 `sprite` 설정)으로 — 편마다 도안을 바꿔도 된다(온돌 편: 지게 진 나무꾼)

## 0. 형식 (10/23 확정 — concept 12)
- **기본 = '그 시절 ○○'**: 2번 비트(개별 건축 편)로 만든다. **[10/23] 질문은 판단 언어로** — "왜 그렇게 짓기로 했을까?"(제약 → 선택 → 대가). 2번 비트의 '당신이라면?→해법'이 곧 판단 구간이다. 1편 쪽구들(0-2). 다음 편 후보는 1번 체크포인트 표로 낸다
- **보류 = '도시의 일생'**: 아래 비트·city_grow.py 명세는 재개할 때 쓴다. 졸본 단독 편은 만들지 않는다(10/17). '고구려 수도 세 번 이사' 편은 10/18 중단 → 10/23 보류. 서울은 문법이 다듬어진 뒤

> 〔archive.md로 이동: '도시의 일생 비트(보류 — v0.2 기록)' — 보류 형식(10/23 '도시의 일생' 보류)〕
## 0-1. 첫 쇼츠에서 배운 것 (10/14 「고구려 수도에 성이 두 개였다고?」 v2, 41.9초)
- 결과: v2 B + `70680658-409f-4175-b3db-3283384b27b5.mp4` (v1 `5a2fb064-8402-464b-b338-df37dd2172c0.mp4`)
- **내레이션을 silenceremove로 다듬지 않는다** — v1에서 문장 사이를 잘라 말끝까지 잘려 '중간중간 끊김' 피드백. 길이가 길면 대본을 줄여 다시 녹음하거나 atempo만 쓴다(문장 사이 0.6초 넘는 쉼만 0.5초로 줄이는 것은 온돌 편에서 문제 없었음 — 말끝 앞뒤 0.25초는 남긴다)
- **코드로만 그린 도해는 '허접하다'** — 배치·단면처럼 그림이 주인공인 장면은 AI 그림 + 코드 표지(anim.json markers)로. 성공 예: 단면 그림 job 0a5720d5-da6a-4766-8a6b-462b598ffa13(롱폼 1부 그림지도를 image_references로 화풍만 가져옴, 9:16 측면 조감)
- **롱폼 그림지도 재활용**: 국내 분지 그림지도 A + `hf_20261004_125300_26f63b4a-0061-4300-88b5-1ea26821c25a.png`(2688x1520). 세로로 쓸 때 가운데 9:16을 잘라 2160x3840으로 키우고, 주요 지형이 자막 띠(출력 y 1130~1610)에 걸리면 그림을 위로 올리고 아래를 뒤집은 띠로 채운다. 단 그 그림의 국내성은 1세기 목책 원형이라 돌 성벽 장면과 모습이 다르다(설명 필요)
- **그림 위 표지**: render.py 지도 장면에 직접 쓴 anim.json(`markers` xy는 2160x3840 원본 좌표, `routes`, `note:""`, `zoom 1.0`)으로 올린다. 제목(y 300~470)·note(y 550)·워터마크 자리를 피한다
- **시대가 다른 지도 바탕**: 지도 v3 bake(1세기 세력 색)를 3~7세기 이야기에 쓰지 않는다 → 세력 색 없는 지형판(`eq.py`로 base.png를 세로 투영, maps/v3_base.png)
- 사용자 의견: 환도산성은 산성이라 더 작아야 하지 않느냐 → 실제로는 환도산성 성벽 약 7km(6,951m)로 국내성(약 2.3~2.7km)보다 길다. 크기 비교가 필요한 장면은 수치를 자막에 넣는다
- 엔딩 질문은 사용자가 바꿈: "고구려는 대체 어떤 트라우마가 있었길래, 이렇게까지 방어에 힘을 쏟았을까요?"(PTSD 대신 트라우마 — 음성 합성 발음)
- 도트 기마병(sprite.py, history-shorts G-4 아래)은 들판·길 위로만. 산 단면을 가로지르면 산 속을 지나가는 것처럼 보여 뺐다
- 사용 크레딧: 1차 약 15(이미지 7 + Kling 1 + TTS) + 2차 약 2

## 0-2. 온돌 편에서 배운 것 (10/19 「그 시절 고구려」 ① 쪽구들, v2 62초)
- 결과: v2 `b51417d5-9055-48c5-a266-3d9d55d2d286.mp4`(v1 `0c9e238d-…`는 표준 포맷 누락으로 폐기)
- **v1 실패 원인**: sandbox 초기화 뒤 렌더러를 새로 짜면서 표준 제목·배지·워터마크·자막 형식이 모두 빠짐 → 사용자 지적 "숏폼 스킬은 참조 안 해?" → 위 ★ 절 신설
- 사용자가 고친 대본 방향: 질문은 지역을 넓게("만주와 한반도 북부의 겨울을 어떻게 이겨냈을까요?"), 전쟁 연결은 대상을 밝혀서("옥저와의 전쟁으로"), 엔딩은 문화로 잇기("온돌을 우리의 핵심 문화 중 하나로 만들었죠"), 숫자는 천 단위 쉼표("1,500년")
- 고대 기온은 기록이 없다 → "당시"로 단정하지 않고 현대 평년값으로 말한다("지금도 영하 7도에서 20도 사이" — 기상청 북한 27개 지점 1월 평균 −7.2℃, 하얼빈 약 −19℃)
- 화면 글자 규칙(라디오 기준) 때문에 지도 표지 이름(졸본·국내성)을 내레이션에도 넣었다. 수도 기간이 확산 시기와 겹치면 '이른 시기' 같은 한정어를 붙인다(국내성은 427년까지 수도)
- 오늘 장면은 코드 도해보다 **수묵화 AI 그림**(아파트 단지 단면 / 방 단면 + 빛나는 온수관)이 낫다 — 코드로 그린 바닥 단면은 '허접하다' 피드백
- 그림의 핵심(온수관 등)이 자막 띠에 걸리면 위쪽 빈 여백을 잘라 올리고 아래를 뒤집은 띠로 채운다

## 1. 공동 구성 체크포인트 (크레딧 쓰기 전)
1. **주제**: 컨셉 12-5 후보 + 새 후보를 표로(수수께끼 · 제약 · 양식 요소 · 개발 논리 · 근거 등급 · 시각 포인트) → 사용자가 고름
2. **고증 시트**(3번): 치수·연대·규정·인물, 출처, 등급. 속설은 반론과 함께
3. **대본**(2번) + 세 역할 검토(도시공학자 / 건축사학자 / 기획자 — 컨셉 12-1)를 나눠 보고. 개발 논리 대목은 사용자(부동산 실무자)의 검토를 따로 요청
4. **컷 시안**: 첫 장면 후보 2~3장 + 도해 1장 시안 → 사용자 확인 후 나머지 생성, 움직이는 컷은 그다음

## 2. 대본 — 45초 (약 43초 내레이션)
- 개별 건축 편 비트(도시의 일생 편은 0번 비트): 시그니처+제목(0~3) → 수수께끼(3~10) → 제약(10~20) → 당신이라면?→해법(20~27) → 원리 도해(27~38) → 남긴 것+질문(38~45). 장면 8~9개, 장면 평균 4.5초 이상
- 반반 규칙: 양식 요소 1~2개(정확한 이름 → 바로 쉬운 풀이: "맨사드, 그러니까 꺾인 지붕") + 개발 논리 1개(오늘의 부동산 비유 하나: "오늘로 치면 용적률을 다 채운 설계")
- 숫자는 편당 3개 이하, 단위는 말로 풀기("약 20미터, 아파트 7층 높이" — 비교 기준은 [추정] 표시 후 설명란에 계산)
- 내레이션 문체·종결 어미·TTS 설정은 history-shorts D-2·F-2 그대로(Harrison 보이스, 128자 지시문)
- 라디오 기준: 도해에 적힌 치수·이름은 모두 말로도 나온다. "보시는 것처럼" 금지
- 엔딩: 오늘의 도시와 잇는 한 줄 + 시청자 질문(고정 댓글과 같은 질문). 질문 없이 '오늘'로 끝내는 엔딩도 가능(온돌 편)

## 3. 고증
- 태그: concept 5-1 마스터 태그 표 — 이 시리즈는 [기록] [통설] [추정] [해석] [연출] [발굴] [복원추정]을 쓴다
- 출처 우선순위: 1차 사료·당대 규정문 → 건축사 학술서·논문 → 박물관·유네스코·국가유산청 등 기관 → 개설서·백과사전. 위키류는 출발점으로만. 검색 결과로 확인한 것만 단정한다
- 치수·연대 표: 항목 | 값 | 출처 | 등급. 출처끼리 다르면 범위로 말하고("약 40여 미터") 설명란에 밝힌다
- 속설(예: 정면 폭 과세 때문에 집이 좁아졌다)은 [통설·논쟁]으로 말하고 반론 한 줄
- 현대 지표(용적률·건폐율·임대수익률)를 과거에 대입하면 [추정] + 가정 치수를 설명란에
- 복원 그림의 세부(색·장식·간판·창호)는 [복원추정]. 확인되지 않은 장식을 핵심 자막으로 쓰지 않는다
- 현존 건물의 실제 사진·영상은 쓰지 않는다. 저작권이 살아 있는 현대 건축물(대략 20세기 후반 이후, 건축가 생존·사후 70년 이내)은 재현하지 않는다

## 4. 실사 복원 컷 (gpt_image_2_5, 9:16, 2k, medium) [미검증 — 첫 편에서 시안 확인]
각 장면 = [STYLE] + [SCENE] + [ERA] + [LAYOUT] + [NEGATIVE]. STYLE·NEGATIVE는 시리즈 안에서 바꾸지 않는다.

[STYLE]
```
Photorealistic cinematic historical reconstruction, shot like a prestige documentary film still on an ARRI Alexa, natural light, accurate period materials and construction methods, realistic weathering, people in period-correct everyday clothing as small figures for scale, atmospheric depth, vertical 9:16.
```
[SCENE] `{시점} of {건물·가로}, {시대·장소}, {시간대·빛}, {사람들의 생활 한 가지}, {형태의 이유가 보이는 디테일}.`
- 시점 세트(같은 시점 연속 금지): `eye-level street view` / `aerial drone view at 120 m looking down at the street grid` / `low-angle view looking up the facade` / `cutaway section view revealing every floor and its use`(단면 컷 — 실사 + 도해 사이 다리) / `interior view`
- 스케일: `a few people walking at street level for scale` — 군중은 원경 실루엣
- 형태의 이유를 보이게: 예 `the identical cornice line running along the whole boulevard`, `stepped setbacks catching the afternoon sun`
[ERA] 편마다 고증 시트에서 문장으로(의상·재료·교통수단). 예: `1870s Paris, horse-drawn carriages, gas street lamps, limestone facades`
[LAYOUT]
- 첫 장면: `Keep the top 25% as calm sky with very little detail for a title overlay; main building in the middle band; keep the lower third simple for subtitles.`
- 나머지: `Keep the lower third simple for subtitles.`
[NEGATIVE]
```
No text, no readable signage, no letters, no logos, no modern objects (cars, power lines, modern street lights, glass curtain walls, air conditioners, satellite dishes), no tourists, no anachronistic materials, no fantasy architecture, no exaggerated ornament, no distorted perspective, no impossible structures, no painterly or illustrated look, no CGI video-game look.
```
- 시대 사람이 나오는 컷은 얼굴 클로즈업 없이(원경·뒷모습)
- 오늘 비교 컷(엔딩)은 실사로 만들지 않는다(현대 건물 재현·초상권 문제 회피) → 수묵화 AI 그림(0-2) 또는 도해

## 5. 시그니처 3초 — 건축판 [미검증]
- 수묵 스틸 = **건물 선묘 스케치**: `Traditional East Asian ink line sketch on warm hanji paper of {첫 장면과 같은 건물·같은 구도}, confident brush outlines, light ink wash shading, generous empty paper, no color, no text.` + NEGATIVE의 글자 금지
- 실사 스틸 = 같은 구도의 실사 복원(4번 STYLE), 수묵 스틸을 image_references로 `Recreate reference image 1 as a photorealistic … with the EXACT same composition. Change only the medium.`
- 실사 → Kling 3.0 움직이는 컷(아래 6번) → 먹 번짐 합성은 history-shorts F-5와 같은 sig 엔진(1080x1920, TOT 4.7 · T0 0.3 · T1 2.1, 떨어지는 위치는 건물 중심 y 0.35~0.5)

## 6. 움직이는 컷 (Kling 3.0, 9:16, 5초, std 7.5 크레딧 — pro는 get_cost로 확인 후 사용자 선택)
- 프롬프트 틀: `Cinematic live-action shot. Camera: {very slow crane up / slow drone glide along the street / slow push-in}. Motion: {people walking, carriages passing, smoke from chimneys, birds, clouds and light shifting across the facade}. The architecture stays perfectly rigid and unchanged. No new buildings, no text, no morphing, no camera cut.`
- 건물이 휘거나 층수가 바뀌는 변형이 가장 흔한 실패로 예상 [미검증] → 정지 프레임 3장(0.5/2.5/4.5초)으로 층수·처마선 확인 후 사용
- `declined_preset_id` 등 제출 규칙은 history-shorts F-4

## 7. 도해 (코드) [그림체 미검증 · diag.py 미구현 — 첫 편에서 작성·시안 확인 후 이 절에 코드 추가]
- 문법 다섯 가지만: **배치도**(가로·필지·블록) / **단면도**(높이·사선·구조) / **입면 띠**(층별 쓰임을 띠로) / **볼륨**(층이 하나씩 쌓이며 연면적이 차오름) / **스케일 비교**(사람 1.7m, 오늘의 건물은 회색 점선)
- 그림체: 한지 바탕(236,227,206) + 먹선(40,34,28) + 강조 1색 진사(170,38,32) + 보조 회색 점선. 글자는 나눔명조 Bold(라벨)·ExtraBold(제목), 치수선은 화살 끝 + 숫자
- 움직임: 선이 그려지며 나타남(draw-on 0.6~1.2초), 층 쌓기(층당 0.15초), 치수 숫자는 선이 다 그려진 뒤 페이드
- 실사 → 도해 전환: 같은 구도의 실사 위에 단면선이 먼저 그려지고 실사가 한지로 바래며 넘어감(트랜지션 'ink' 대신 덧그리기) [미구현 — 첫 편은 render.py의 ink 전환으로 대체 가능]
- 출력: diag.py가 spec(json) → 1080x1920·30fps mp4 → scenes.json 해당 장면 `video`로. render.py는 영상 컷에 채도 1.15·대비 1.05 보정을 거므로 한지색이 약간 진해진다(온돌 편에서 문제 없었음)
- spec 초안: `{"dur":5,"items":[{"t":"line","pts":[[x,y],…],"w":6,"color":"ink","at":0.2,"dur":0.8},{"t":"dim","a":[x,y],"b":[x,y],"text":"20 m","at":1.2},{"t":"floors","base":[x,y],"w":600,"h":60,"n":6,"at":1.5,"step":0.15,"labels":["상점","귀족층",…]},{"t":"human","x":..,"y":..,"h":1.7},{"t":"ghost","label":"오늘의 아파트 15층","h":45}]}` — 좌표는 실제 미터를 화면 축척(예: 1 m = 30 px)으로 바꿔 넣는다. 치수는 고증 시트 값만
- 자막 띠(y 1130~1610)·제목(y 300~470)을 피해 핵심 도해는 y 520~1100에

## 8. 렌더 · 톤
- render.py v7.6 그대로(history-shorts G, ★ 절). 실사 복원 이미지도 grade()를 거쳐 채도 +22%·따뜻/청록 톤·한지 결이 얹힌다 → 실사에 한지 결이 어색하면 scenes.json `"saturation"` 낮추기, 그래도 어색하면 render.py에 장면별 `"grade":"none"` 옵션 추가 [미구현]. 첫 편 PREVIEW로 판단
- 코드로 그린 한지 지도는 grade()를 피하려고 `map` 키(빈 markers의 anim.json이라도)를 붙여 지도 장면으로 넣는다
- 효과음: 도시 앰비언스(`amb: river` 또는 생성 효과음 — 마차·군중·종소리, history-shorts F-6의 RMS 기준)
- 출처 줄(`source`): `{주요 출처} · 이미지는 AI 재현`

## 9. QA (history-shorts H에 더해)
- 표준 화면 요소(★ 절)가 모두 있는가 — 제목·배지·워터마크·2줄 자막·출처
- 도해 치수 = 고증 시트 값인가, 축척이 한 도해 안에서 일정한가
- 실사 컷: 시대에 없는 물건(전선·유리 커튼월·자동차), 가짜 글자 간판, 층수·처마선 변형
- 반반 점검: 양식 요소 1~2개를 이름+풀이로 말했는가, 개발 논리 1개를 비유로 말했는가
- 속설을 단정하지 않았는가, [추정] 지표의 계산 근거가 설명란에 있는가
- 한계 고지: 움직임은 정지 프레임으로만, 소리는 수치로만 확인했음을 보고

> 〔현행 규칙 — `reference-upload.md`에 있음: '10. 메타데이터'. 업로드 메타데이터를 쓸 때만 읽는다〕
> 〔archive.md로 이동: '11. 결정 기록' — 변경 이력 표 — 현행 값은 원장〕
